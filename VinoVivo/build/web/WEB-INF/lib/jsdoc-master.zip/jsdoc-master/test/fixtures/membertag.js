/** @member */
var x;

/** @var foobar */
/** @var {string} baz */

/** @member {Object} */
var y;
