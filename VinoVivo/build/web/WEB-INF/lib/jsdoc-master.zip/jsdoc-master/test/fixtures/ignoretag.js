/**
    @ignore
*/
function foo(x) {

}
