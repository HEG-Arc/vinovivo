/** @func Foo */
function Foo() {
}

/** @method */
function Bar() {
}
