Before editing the documentation for JSDoc 3, please consider these notes:

- This site is built from data files and templates
- To add or modify content, you must make changes in the `Jake/articles` folder
- Before committing, build the HTML by running the `jake` command in the project root

See: https://github.com/mde/jake

Thank you!